public class tugasperulangan6 {
    public static void main(String[] args) {
      
        System.out.println("Deret huruf A sampai Z:");
        char huruf = 'A'; 
        while (huruf <= 'Z') { 
            System.out.print(huruf + " ");
            huruf++; 
        }
        System.out.println(); 
    }
}