public class tugasperulangan8 {
    public static void main(String[] args) {
        int i = 1;
        int jumlahPerulangan = 10; 

        while (i <= jumlahPerulangan) { 
            System.out.println(i + ". Saya berjanji tidak akan mengulangi kesalahan lagi");
            i++; 
        }
    }
}
