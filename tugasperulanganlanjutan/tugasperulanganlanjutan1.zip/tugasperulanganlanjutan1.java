public class tugasperulanganlanjutan1 {
    public static void main(String[] args) {
       
        for (int i = 1; i > 0; i++) {
            System.out.println(i); 

            if (i == 10) {
                break; 
            }
        }

        System.out.println("Perulangan dihentikan pada angka 10.");
    }
}
